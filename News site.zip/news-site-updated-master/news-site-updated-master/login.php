Name: <input type="text" name="name" ><br>
Password: <input type="Password" name="pass" >

